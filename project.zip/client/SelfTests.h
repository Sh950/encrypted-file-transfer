#pragma once
int runSelfTests();